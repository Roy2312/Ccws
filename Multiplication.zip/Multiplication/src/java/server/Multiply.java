/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Tanmai
 */
@WebService(serviceName = "Multiply")
public class Multiply {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "multiply")
    public Double multiply(@WebParam(name = "a") double a, @WebParam(name = "b") double b) {
        //TODO write your implementation code here:
        return a*b;
    }

    /**
     * This is a sample web service operation
     */
  
    
}
