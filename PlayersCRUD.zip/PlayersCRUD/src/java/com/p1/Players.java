/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.p1;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Tanmai
 */
@Entity
@XmlRootElement
public class Players implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String playername;

    /**
     * Get the value of playername
     *
     * @return the value of playername
     */
    public String getPlayername() {
        return playername;
    }

    /**
     * Set the value of playername
     *
     * @param playername new value of playername
     */
    public void setPlayername(String playername) {
        this.playername = playername;
    }

    private int playerage;

    /**
     * Get the value of playerage
     *
     * @return the value of playerage
     */
    public int getPlayerage() {
        return playerage;
    }

    /**
     * Set the value of playerage
     *
     * @param playerage new value of playerage
     */
    public void setPlayerage(int playerage) {
        this.playerage = playerage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Players)) {
            return false;
        }
        Players other = (Players) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.p1.Players[ id=" + id + " ]";
    }
    
}
