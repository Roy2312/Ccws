/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Tanmai
 */
@WebService(serviceName = "factorial")
public class factorial {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "findFact")
    public String findFact(@WebParam(name = "a") double a) {
        //TODO write your implementation code here:
       if (a < 0 || a != Math.floor(a)) {
        return "Error: Please enter a non-negative integer.";
    }

    int number = (int) a;
    long fact = 1;
    for (int i = 2; i <= number; i++) {
        fact *= i;
    }

    return "Factorial of " + number + " is " + fact;
    }

}
